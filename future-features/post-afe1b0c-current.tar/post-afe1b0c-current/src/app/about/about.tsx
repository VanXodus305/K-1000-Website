"use client";

import { useState, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { leadership } from "@/data/leadership";
import SharedHeader from "../../components/ui/SharedHeader";
import Footer from "../../components/footer/Footer";
import CubeBackground from "../../components/ui/CubeBackground";
import LeadershipProfileCard from "../../components/about/LeadershipProfileCard";
import { SITE_TAGLINE } from "../../data/site";

const conthrax = "font-['Conthrax',_Arial]";

const councilContainerMap: Record<number, string> = {
  1: "flex flex-wrap justify-center gap-5 md:gap-8 max-w-[1040px]",
  2: "flex flex-wrap justify-center gap-5 md:gap-8 max-w-[1560px]",
  3: "flex flex-wrap justify-center gap-5 md:gap-8 max-w-[1560px]",
};

const councilItemMap: Record<number, string> = {
  1: "w-full max-w-[380px] sm:w-[calc(50%-0.625rem)]",
  2: "w-full max-w-[340px] sm:w-[calc(50%-0.625rem)] xl:w-[calc(25%-1.5rem)]",
  3: "w-full max-w-[340px] sm:w-[calc(50%-0.625rem)] xl:w-[calc(25%-1.5rem)]",
};

type BoardMember = {
  id: string;
  name: string;
  position: string;
  image: string;
  description: string;
};

export default function AboutPage() {
  const [selectedMember, setSelectedMember] = useState<BoardMember | null>(null);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    document.body.style.overflow = selectedMember ? "hidden" : "unset";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [selectedMember]);

  const board = useMemo(() => [
    {
      id: "vc-1",
      name: "Prof. Dr. Saranjit Singh",
      position: "Vice Chancellor",
      image: "/about/member-1.jpg",
      description: "Prof. (Dr.) Saranjit Singh received his Ph.D. in Production Engineering from BIT Mesra, M.Tech. from IIT Varanasi (formerly IT-BHU), and B.E. in Mechanical Engineering from Savitribai Phule Pune University. With extensive teaching and research experience, his interests span material processing technologies, metal forming of advanced materials like sintered and foam composites, cleaner manufacturing, DFX methodologies, and quality management.",
    },
    {
      id: "reg-2",
      name: "Prof. Dr. Jnyana Ranjan Mohanty",
      position: "Registrar",
      image: "/about/member-2.jpg",
      description: "With over 28 years of rich experience in research, academic development, and innovation, Prof. Mohanty serves as the Registrar of KIIT University. He has been instrumental in shaping the university's administrative framework and innovation ecosystem.",
    },
    {
      id: "fi-3",
      name: "Dr. Ajit Kumar Pasayat",
      position: "Faculty Incharge",
      image: "/about/member-3.jpg",
      description: "Holding a Ph.D. and M.Tech. from IIT Kharagpur, Dr. Pasayat is a specialist in AI/ML, Data Analytics, and Cognitive Systems. As the Faculty Incharge, he bridges the gap between theoretical research and industrial application.",
    },
  ], []);

  return (
    <div className="flex flex-col items-center w-full bg-black text-white selection:bg-cyan-500/30 overflow-x-hidden relative">
      <SharedHeader />
      <CubeBackground disableLinesOnMobile />
      <div className="fixed inset-0 bg-[radial-gradient(circle_at_50%_50%,#0ea5e90a_0%,transparent_70%)] pointer-events-none z-[2]" />

      <main className="relative z-10 w-full flex flex-col items-center">
        {/* HERO SECTION */}
        <section className="w-full flex flex-col items-center px-0 md:px-6 pt-24 md:pt-32 lg:pt-40 opacity-0 animate-fade-in [animation-fill-mode:forwards]">
          <div className="relative w-[92%] md:w-full h-[30vh] md:h-[40vh] md:aspect-[21/7] md:max-h-[500px] md:rounded-[40px] overflow-hidden border border-cyan-500/20 bg-black shadow-2xl">
            <img src="/about/KIIT.jpg" className="absolute inset-0 w-full h-full object-cover brightness-[0.3]" alt="KIIT Campus" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
            <div className="relative z-10 flex flex-col items-center justify-center text-center p-6 h-full">
              <h1 className={`${conthrax} text-3xl sm:text-5xl md:text-7xl tracking-tighter text-white uppercase font-black`}>
                ABOUT <span className="text-cyan-400 drop-shadow-[0_0_15px_#00f7ff]">K-1000</span>
              </h1>
              <p className={`${conthrax} text-cyan-400/50 mt-4 tracking-[0.2em] md:tracking-[0.5em] text-[10px] md:text-sm uppercase font-bold`}>
                {SITE_TAGLINE}
              </p>
            </div>
          </div>
        </section>

        {/* FOUNDER SECTION */}
        <section className="w-full px-4 md:px-20 py-12 md:py-24 flex flex-col items-center border-t border-white/5">
          <div className="w-full max-w-[1400px]">
            <div className="relative overflow-hidden p-6 md:p-16 rounded-[32px] md:rounded-[60px] border border-white/10 bg-[#0a0a0c]/60 backdrop-blur-xl shadow-[0_0_50px_rgba(0,0,0,0.4)]">
              <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/5 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-20 items-center relative z-10">
                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-cyan-500/20 to-transparent rounded-2xl md:rounded-[40px] blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
                  <img src="/about/Founder.png" className="relative w-full h-auto max-h-[500px] md:max-h-none object-contain brightness-95 rounded-2xl md:rounded-[40px] transition-transform duration-700 group-hover:scale-[1.02]" alt="Founder" />
                </div>
                {/* Changed to text-left for all states */}
                <div className="flex flex-col space-y-5 md:space-y-8 text-left">
                  <div className="space-y-3">
                    <h2 className={`${conthrax} text-2xl md:text-6xl text-white uppercase leading-tight tracking-tighter font-black`}>
                      OUR <span className="text-cyan-400 drop-shadow-[0_0_15px_rgba(0,247,255,0.3)]">FOUNDER</span>
                    </h2>
                    <div className="w-16 md:w-24 h-1 bg-cyan-400 shadow-[0_0_15px_#00f7ff]" />
                  </div>
                  <div className="space-y-4 md:space-y-6">
                    <span className={`${conthrax} text-cyan-400 block text-xs md:text-xl tracking-[0.2em] uppercase font-black`}>
                      Prof. Dr. Achyuta Samanta
                    </span>
                    {/* UPDATED: removed text-justify, explicitly added text-left */}
                    <p className="text-[11px] md:text-lg text-white/60 leading-relaxed font-normal text-left">
                      Prof. Dr. Achyuta Samanta&apos;s life story reads like a powerful saga of grit, determination, and social responsibility. Born and brought up in poverty in a remote village in Odisha, he was dealt a cruel blow at the tender age of four when he lost his father, after which his life became a struggle for food and education for 15 long years. 
                      <br /><br />
                      However, he persevered, and at the age of 22, joined teaching. At 25, he embarked on a journey that would change his own life, and the lives of thousands of people. With just Rs 5000 in his pocket, he started KIIT and KISS in two rented houses.
                    </p>
                  </div>
                  <div className="flex items-center gap-2 pt-4 border-t border-white/5">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* BOARD MEMBERS SECTION */}
        <section className="w-full max-w-7xl px-6 md:px-10 py-14 md:py-20 flex flex-col items-center">
          <h2 className={`${conthrax} text-2xl md:text-4xl text-center tracking-[0.2em] md:tracking-[0.3em] text-cyan-400 mb-12 md:mb-16 uppercase font-black`}>
            Board Members
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12 w-full">
            {board.map((m) => (
              <div key={m.id} onClick={() => setSelectedMember(m)} className="cursor-pointer flex flex-col items-center group">
                <div className="w-full aspect-[4/5] rounded-[24px] overflow-hidden border border-white/5 bg-[#0a0a0a]/80 backdrop-blur-sm group-hover:border-cyan-500/50 transition-all duration-500 shadow-2xl">
                  <img src={m.image} className="size-full object-cover object-[center_15%] transition-transform duration-700 group-hover:scale-110" alt={m.name} />
                </div>
                {/* Names and positions are typically center-centric in grids, but kept text-left for the content containers */}
                <h3 className={`${conthrax} text-sm md:text-lg text-white mt-5 text-center tracking-wide group-hover:text-cyan-400 transition-colors uppercase leading-tight font-black`}>
                  {m.name}
                </h3>
                <p className={`${conthrax} text-cyan-400 text-[10px] md:text-[13px] uppercase mt-2 tracking-[0.2em] font-bold text-center`}>
                  {m.position}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* CORE TEAM SECTION — hidden */}

        <section className="hidden w-full max-w-[1480px] px-4 sm:px-6 py-12 md:py-20 border-t border-white/5">
          <h2 className={`${conthrax} text-center text-3xl sm:text-4xl md:text-7xl mb-10 md:mb-16 text-white uppercase tracking-tighter font-black`}>
            CORE <span className="text-cyan-400">TEAM</span>
          </h2>
          {leadership.hierarchy.map((grp, gi) => (
            <div key={gi} className="w-full flex flex-col items-center mb-12 md:mb-20">
              <div className="mb-8 md:mb-10 flex flex-col items-center gap-3 text-center">
                <h3 className={`${conthrax} text-xl md:text-3xl text-white uppercase tracking-[0.16em] font-black`}>
                  {grp.title}
                </h3>
                <div className="h-px w-24 bg-gradient-to-r from-transparent via-cyan-400/80 to-transparent shadow-[0_0_12px_rgba(0,247,255,0.45)]" />
              </div>
              <div className={`${councilContainerMap[grp.level] || "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5 md:gap-8 max-w-[1280px]"} w-full`}>
                {grp.members.map((m, mi) => (
                  <div key={mi} className={councilItemMap[grp.level]}>
                    <LeadershipProfileCard
                      name={m.name}
                      position={m.position}
                      image={m.image}
                      branch={m.branch}
                      variant="standard"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </section>
      </main>

      {/* MEMBER MODAL */}
      <AnimatePresence>
        {selectedMember && (
          <div className="fixed inset-0 z-[300] flex items-center justify-center p-4">
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={() => setSelectedMember(null)} className="absolute inset-0 bg-black/80 backdrop-blur-md" />
            <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.98 }} className="relative w-full max-w-4xl bg-[#050505]/90 backdrop-blur-2xl border border-cyan-500/30 rounded-[32px] overflow-hidden flex flex-col md:flex-row shadow-[0_0_50px_rgba(0,247,255,0.15)]">
              <div className="w-full md:w-[45%] h-[280px] md:h-auto overflow-hidden">
                <img src={selectedMember.image} className="size-full object-cover object-[center_15%]" alt={selectedMember.name} />
              </div>
              {/* UPDATED: text-left alignment for modal body */}
              <div className="flex-1 p-8 md:p-12 flex flex-col justify-center text-left">
                <h3 className={`${conthrax} text-xl md:text-3xl text-white uppercase font-black`}>{selectedMember.name}</h3>
                <p className={`${conthrax} text-cyan-400 text-sm mt-3 tracking-widest uppercase font-bold`}>{selectedMember.position}</p>
                <div className="h-px w-16 bg-cyan-500 my-6 shadow-[0_0_10px_#00f7ff]" />
                <p className="text-white/60 text-sm md:text-base leading-relaxed font-light text-left">
                  {selectedMember.description}
                </p>
                <button onClick={() => setSelectedMember(null)} className={`${conthrax} mt-8 text-[10px] text-cyan-400/50 uppercase tracking-widest hover:text-white transition-colors font-black text-left`}>
                  Close Profile
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
      <Footer />
    </div>
  );
}
